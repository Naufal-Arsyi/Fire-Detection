# fire detection > versiontest
https://universe.roboflow.com/fire-detection-3acsn/fire-detection-6xj8n

Provided by a Roboflow user
License: CC BY 4.0

